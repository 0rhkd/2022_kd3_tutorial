from django.contrib import admin

from secondapp.models import Course

admin.site.register(Course)